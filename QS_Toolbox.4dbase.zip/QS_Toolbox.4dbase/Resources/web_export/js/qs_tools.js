$(document).ready(function(){
	/*$('[id^="a_node"]').click(function() {

alert(this.id.value);


});
*/
});